import React from 'react'
import Site_Header from '../components/Site_Header'

function about() {
  return (
    <div>
        
        <Site_Header />
        about page</div>
  )
}

export default about