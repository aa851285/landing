import React from 'react'
import Site_Header from '../components/Site_Header'

function contact() {
  return (
    <div>
        <Site_Header />
        contact page</div>
  )
}

export default contact